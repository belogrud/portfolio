-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA1

Format: 1.0
Source: cfg2html-linux
Binary: cfg2html-linux
Architecture: all
Version: 2.94-2
Maintainer: Ralph Roth <cfg2html@hotmail.com>; Michael Meifert <dk3hg@users.sourceforge.net>; Gratien Dhaese <gratien.dhaese@gmail.com>
Homepage: http://www.cfg2html.com/
Vcs-Git: https://github.com/cfg2html/cfg2html
Package-List: 
 cfg2html-linux deb admin optional
Checksums-Sha1: 
 2221445c4fea5417a2aac52f98b3625f37ce11ec 136815 cfg2html-linux_2.94-2.tar.gz
Checksums-Sha256: 
 2d04abf9c068acdfbe31036c93dd97e5fc2efe053fa8b79d2717da5e3db37741 136815 cfg2html-linux_2.94-2.tar.gz
Files: 
 80178575b44e480bb9dbbb3917c5682c 136815 cfg2html-linux_2.94-2.tar.gz

-----BEGIN PGP SIGNATURE-----
Version: GnuPG v1.4.12 (GNU/Linux)

iEYEARECAAYFAlPok8kACgkQTOokfjQmo2kizQCgicNG8o1nCeH7HabNPNaL368a
33kAn20pNRSZdGbUqlLj+18OwwY7D9+Z
=7dmw
-----END PGP SIGNATURE-----
