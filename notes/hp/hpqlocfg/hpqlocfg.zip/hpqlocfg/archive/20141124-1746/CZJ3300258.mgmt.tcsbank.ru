
Server IP is : CZJ3300258.mgmt.tcsbank.ru:443
<?xml version="1.0"?>
<RIBCL VERSION="2.23">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
</RIBCL>
<?xml version="1.0"?>
<RIBCL VERSION="2.23">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
</RIBCL>
<?xml version="1.0"?>
<RIBCL VERSION="2.23">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
</RIBCL>
<?xml version="1.0"?>
<RIBCL VERSION="2.23">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
<GET_ALL_USER_INFO>
<GET_USER
    USER_NAME="Administrator"
    USER_LOGIN="Administrator"
    ADMIN_PRIV="Y"
    REMOTE_CONS_PRIV="Y"
    RESET_SERVER_PRIV="Y"
    VIRTUAL_MEDIA_PRIV="Y"
    CONFIG_ILO_PRIV="Y"
    />
</GET_ALL_USER_INFO>
</RIBCL>
<?xml version="1.0"?>
<RIBCL VERSION="2.23">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
</RIBCL>
<?xml version="1.0"?>
<RIBCL VERSION="2.23">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
</RIBCL>


Script succeeded for DNS:CZJ3300258.mgmt.tcsbank.ru:443
