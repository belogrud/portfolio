Server IP is : CZ3332KYND.mgmt.tcsbank.ru:443
ERROR
Script failed for DNS:CZ3332KYND.mgmt.tcsbank.ru:443