Server IP is : CZ3332KYP1.mgmt.tcsbank.ru:443
<?xml version="1.0"?>
<RIBCL VERSION="2.22">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
</RIBCL>
<?xml version="1.0"?>
<RIBCL VERSION="2.22">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
</RIBCL>
<?xml version="1.0"?>
<RIBCL VERSION="2.22">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
</RIBCL>
<?xml version="1.0"?>
<RIBCL VERSION="2.22">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
</RIBCL>
<?xml version="1.0"?>
<RIBCL VERSION="2.22">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
<GET_DIR_CONFIG>
    <DIR_AUTHENTICATION_ENABLED VALUE="Y"/>
    <DIR_LOCAL_USER_ACCT VALUE="Y"/>
    <DIR_SERVER_ADDRESS VALUE= "ldap.mgmt.tcsbank.ru"/>
    <DIR_SERVER_PORT VALUE= "636"/>
    <DIR_OBJECT_DN VALUE= ""/>
    <DIR_USER_CONTEXT_1 VALUE= "dn=tcsbank,dn=ru"/>
    <DIR_USER_CONTEXT_2 VALUE= ""/>
    <DIR_USER_CONTEXT_3 VALUE= ""/>
    <DIR_USER_CONTEXT_4 VALUE= ""/>
    <DIR_USER_CONTEXT_5 VALUE= ""/>
    <DIR_USER_CONTEXT_6 VALUE= ""/>
    <DIR_USER_CONTEXT_7 VALUE= ""/>
    <DIR_USER_CONTEXT_8 VALUE= ""/>
    <DIR_USER_CONTEXT_9 VALUE= ""/>
    <DIR_USER_CONTEXT_10 VALUE= ""/>
    <DIR_USER_CONTEXT_11 VALUE= ""/>
    <DIR_USER_CONTEXT_12 VALUE= ""/>
    <DIR_USER_CONTEXT_13 VALUE= ""/>
    <DIR_USER_CONTEXT_14 VALUE= ""/>
    <DIR_USER_CONTEXT_15 VALUE= ""/>
    <DIR_ENABLE_GRP_ACCT VALUE= "Y"/>
    <DIR_GRPACCT1_NAME VALUE= "Administrators"/>
    <DIR_GRPACCT1_PRIV VALUE= "1,2,3,4,5,6"/>
    <DIR_GRPACCT1_SID VALUE= ""/>
    <DIR_GRPACCT2_NAME VALUE= "Authenticated Users"/>
    <DIR_GRPACCT2_PRIV VALUE= "6"/>
    <DIR_GRPACCT2_SID VALUE= "S-1-5-11"/>
    <DIR_GRPACCT3_NAME VALUE= "CN=ilo_admin_full,OU=Security Groups,DC=tcsbank,DC=ru"/>
    <DIR_GRPACCT3_PRIV VALUE= "1,2,3,4,5,6"/>
    <DIR_GRPACCT3_SID VALUE= "S-1-5-21-2759251321-3792594990-2533694615-10038"/>
    <DIR_GRPACCT4_NAME VALUE= "CN=ilo_admin_power_only,OU=Security Groups,DC=tcsbank,DC=ru"/>
    <DIR_GRPACCT4_PRIV VALUE= "3,6"/>
    <DIR_GRPACCT4_SID VALUE= "S-1-5-21-2759251321-3792594990-2533694615-10039"/>
    <DIR_KERBEROS_ENABLED VALUE="N"/>
    <DIR_KERBEROS_REALM VALUE=""/>
    <DIR_KERBEROS_KDC_ADDRESS VALUE= ""/>
    <DIR_KERBEROS_KDC_PORT VALUE= "88"/>
</GET_DIR_CONFIG>
</RIBCL>
<?xml version="1.0"?>
<RIBCL VERSION="2.22">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
</RIBCL>
<?xml version="1.0"?>
<RIBCL VERSION="2.22">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
</RIBCL>
<?xml version="1.0"?>
<RIBCL VERSION="2.22">
<RESPONSE
    STATUS="0x0000"
    MESSAGE='No error'
     />
</RIBCL>


Script succeeded for DNS:CZ3332KYP1.mgmt.tcsbank.ru:443