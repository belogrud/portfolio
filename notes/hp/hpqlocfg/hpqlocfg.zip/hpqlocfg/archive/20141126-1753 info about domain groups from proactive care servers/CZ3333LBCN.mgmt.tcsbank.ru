Server IP is : CZ3333LBCN.mgmt.tcsbank.ru:443
ERROR
Script failed for DNS:CZ3333LBCN.mgmt.tcsbank.ru:443