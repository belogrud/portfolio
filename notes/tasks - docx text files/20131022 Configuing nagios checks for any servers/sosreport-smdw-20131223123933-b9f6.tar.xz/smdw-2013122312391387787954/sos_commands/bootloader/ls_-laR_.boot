/boot:
total 38732
dr-xr-xr-x.  5 root root     4096 Dec 17 13:01 .
dr-xr-xr-x. 26 root root     4096 Dec 23 11:20 ..
-rw-r--r--.  1 root root   100182 May 10  2011 config-2.6.32-131.0.15.el6.x86_64
-rw-r--r--   1 root root   100948 Jun 12  2012 config-2.6.32-220.23.1.el6.x86_64
drwxr-xr-x.  3 root root     4096 Jun 28  2011 efi
drwxr-xr-x.  2 root root     4096 Dec 19 15:05 grub
-rw-r--r--.  1 root root 13183911 Feb 26  2013 initramfs-2.6.32-131.0.15.el6.x86_64.img
-rw-r--r--   1 root root 13460285 Dec 17 12:51 initramfs-2.6.32-220.23.1.el6.x86_64.img
drwx------.  2 root root    16384 Jun 28  2011 lost+found
-rw-r--r--.  1 root root   165812 May 11  2011 symvers-2.6.32-131.0.15.el6.x86_64.gz
-rw-r--r--   1 root root   171233 Jun 12  2012 symvers-2.6.32-220.23.1.el6.x86_64.gz
-rw-r--r--.  1 root root  2278446 May 10  2011 System.map-2.6.32-131.0.15.el6.x86_64
-rw-r--r--   1 root root  2314801 Jun 12  2012 System.map-2.6.32-220.23.1.el6.x86_64
-rwxr-xr-x.  1 root root  3881120 May 10  2011 vmlinuz-2.6.32-131.0.15.el6.x86_64
-rw-r--r--.  1 root root      171 May 10  2011 .vmlinuz-2.6.32-131.0.15.el6.x86_64.hmac
-rwxr-xr-x   1 root root  3941488 Jun 12  2012 vmlinuz-2.6.32-220.23.1.el6.x86_64
-rw-r--r--   1 root root      171 Jun 12  2012 .vmlinuz-2.6.32-220.23.1.el6.x86_64.hmac

/boot/efi:
total 12
drwxr-xr-x. 3 root root 4096 Jun 28  2011 .
dr-xr-xr-x. 5 root root 4096 Dec 17 13:01 ..
drwxr-xr-x. 3 root root 4096 Jun 28  2011 EFI

/boot/efi/EFI:
total 12
drwxr-xr-x. 3 root root 4096 Jun 28  2011 .
drwxr-xr-x. 3 root root 4096 Jun 28  2011 ..
drwxr-xr-x. 2 root root 4096 Jun 28  2011 redhat

/boot/efi/EFI/redhat:
total 252
drwxr-xr-x. 2 root root   4096 Jun 28  2011 .
drwxr-xr-x. 3 root root   4096 Jun 28  2011 ..
-rwxr-xr-x. 1 root root 247570 Jan 22  2011 grub.efi

/boot/grub:
total 296
drwxr-xr-x. 2 root root   4096 Dec 19 15:05 .
dr-xr-xr-x. 5 root root   4096 Dec 17 13:01 ..
-rw-r--r--. 1 root root     63 Jul  1  2011 device.map
-rw-r--r--. 1 root root     63 Jun 28  2011 device.map.rpmsave
-rw-r--r--. 1 root root  13396 Jul  1  2011 e2fs_stage1_5
-rw-r--r--. 1 root root  12620 Jul  1  2011 fat_stage1_5
-rw-r--r--. 1 root root  11764 Jul  1  2011 ffs_stage1_5
-rw-------  1 root root   1195 Dec 19 15:05 grub.conf
-rw-------. 1 root root    801 Jun 28  2011 grub.conf.rpmsave
-rw-r--r--. 1 root root  11772 Jul  1  2011 iso9660_stage1_5
-rw-r--r--. 1 root root  13300 Jul  1  2011 jfs_stage1_5
lrwxrwxrwx. 1 root root     11 Jul  1  2011 menu.lst -> ./grub.conf
lrwxrwxrwx. 1 root root     11 Jun 28  2011 menu.lst.rpmsave -> ./grub.conf
-rw-r--r--. 1 root root  11956 Jul  1  2011 minix_stage1_5
-rw-r--r--. 1 root root  14444 Jul  1  2011 reiserfs_stage1_5
-rw-r--r--. 1 root root   1341 May  6  2010 splash.xpm.gz
-rw-r--r--. 1 root root    512 Jul  1  2011 stage1
-rw-r--r--. 1 root root 126040 Jul  1  2011 stage2
-rw-r--r--. 1 root root  12040 Jul  1  2011 ufs2_stage1_5
-rw-r--r--. 1 root root  11396 Jul  1  2011 vstafs_stage1_5
-rw-r--r--. 1 root root  13980 Jul  1  2011 xfs_stage1_5

/boot/lost+found:
total 20
drwx------. 2 root root 16384 Jun 28  2011 .
dr-xr-xr-x. 5 root root  4096 Dec 17 13:01 ..
